# export-excel
a tool for export data of table to excel

> excel 导出数据库数据小工具

## Build Setup

``` bash
# install dependencies
npm install

# copy config files and config
cp config/mysql-template.js config/mysql.js

# run standard check and serve at localhost:5002

# run program 
example: node index.js -s '2018-07-01' -e '2018-08-01'

```
