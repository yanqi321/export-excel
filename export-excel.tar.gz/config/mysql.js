module.exports = {
  'local': {
    'username': 'root',
    'password': 'root',
    'database': 'wemediadb',
    'host': '127.0.0.1',
    'charset': 'utf8mb4_unicode_ci',
    'limitSize': 200
  },
  'wemedia': {
    'username': 'admin',
    'password': 'Admin_user_2017',
    'database': 'wemediadb',
    'host': 'alias-wemediadb',
    'charset': 'utf8mb4_unicode_ci',
    'limitSize': 200
  },
  "log": {
    "username": "writer_user",
    "password": "Writer_user_2017",
    "database": "logdb",
    "host": "sgwm2",
    "charset": "utf8mb4_unicode_ci",
    "limitSize": 20
  },
  'remote': {
    'username': 'art_stat',
    'password': 'Happy_stat_2016',
    'database': 'artdb',
    'host': '47.88.240.13',
    'charset': 'utf8mb4_unicode_ci',
    'limitSize': 200
  }
}
