module.exports = {
  'local': {
    'username': '',
    'password': '',
    'database': '',
    'host': '127.0.0.1',
    'charset': 'utf8mb4_unicode_ci',
    'limitSize': 200
  },
  'remote': {
    'username': '',
    'password': '',
    'database': '',
    'host': '',
    'charset': 'utf8mb4_unicode_ci',
    'limitSize': 200
  }
}
